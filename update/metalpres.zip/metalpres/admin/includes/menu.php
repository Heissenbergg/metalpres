<div id="menu">
		<ul>
			<li><a href="#">MENU</a></li>
			<li><a href="index.php">DASHBOARD</a></li>
			<li><a href="slider.php">SLIDER</a></li>
			<li><a href="newpost.php">NOVI POST</a></li>
			<li><a href="allposts.php">SVI POSTOVI</a></li>
			<li><a href=""></a></li>
		</ul>
	</div>