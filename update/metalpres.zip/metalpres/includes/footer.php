<div id="footer">
	<div id="footerLeft">
		<h3><b>LINKOVI</b></h3>
		<a href="index.php">Naslovna</a> <br><br>
		<a href="products.php">Proizvodi</a><br><br>
		<a href="about.php">O nama</a><br><br>
		<a href="contact.php">Kontakt</a>
	</div>
	
	<div id="footerMiddle">
		<h3 style="color:#ff7709; font-size: 25px;">METALPRES</h3>
		<p class="coolfontHehe">
			<b>Šepići bb, Cazin</b><br><br>
			<b>+387/37 512-700</b><br><br>
			<b>+387/61 814-135</b><br><br>
			<b>kapic_mirza@hotmail.com</b><br><br>
			<b>metalpres@bih.net.ba</b><br><br>
			<i id="facebook" class="fa fa-facebook-square" aria-hidden="true"></i>
			<i id="instagram" class="fa fa-instagram" aria-hidden="true"></i>
			<i id="linkedin" class="fa fa-linkedin-square" aria-hidden="true"></i>
			<i id="twitter" class="fa fa-twitter" aria-hidden="true"></i>
		</p>
	</div>
	
	<div id="footerRight">
		<h3>O NAMA</h3>
		<a> Naše iskustvo nas razlikuje od drugih kao i kvaliteta koja je dokaz naših zadovoljnih klijenata koji govore sami za sebe.</a>
	</div>
</div>