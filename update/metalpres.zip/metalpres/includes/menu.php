<script src="//code.jquery.com/jquery-1.10.2.js"></script>
<script src="//code.jquery.com/ui/1.11.4/jquery-ui.js"></script>
<div id="topNav">
	<img onclick="menuRight();" id="menuIcon" src="icon/menu.png">
	<label style="display: none;" onclick="showSearchArea();" for="inputSearchArea">
		<p id="searchText">Pretražite ..</p>
		<img id="searchIcon" src="icon/search.png"></img>
	</label>
	<div id="middleLogo">
		<img src="icon/logo.png">
	</div>
	<img id="loginIcon" src="icon/login.png">
	<p id="loginButton"><a href="login.php">Prijavite se</a></p>
</div>

<div id="searchArea">
	<img onclick="hideSearchArea();" id="exitSearchArea" src="icon/exit.png"></img>
	<form>
		<input type="text" id="inputSearchArea" name="inputSearchArea" placeholder="Pokušajte : spavaće sobe"/>
	</form>
</div>

<div id="sideMenu">
	<img onclick="menuLeft();" id="hideMenu" src="icon/arrowLeft.png">
	<div id="divMenuHeader">
		<p id="menuHeader">MENU</p>
	</div>
	<div id="menuOptions">
		<ul>
			<li class="underline"><p><a href="index.php">NASLOVNA</a></p></li>
			<li class="underline"><p onclick="pokaziProizvode();"><a href="#">PROIZVODI</a></p></li>
			<li class="insideParts"><p><a href="kanalice.php">Kanalice</a></p></li>
			<li class="insideParts"><p><a href="ograde.php">Ograde</a></p></li>
			<li class="insideParts"><p><a href="podesti.php">Podesti</a></p></li>
			<li class="insideParts"><p><a href="stepenici.php">Stepenici</a></p></li>
			<li class="insideParts"><p><a href="stubovi.php">Stubovi</a></p></li>
			<li class="underline"><p><a href="onama.php">O NAMA</a></p></li>
			<li class="underline"><p><a href="contact.php">KONTAKT</a></p></li>
			<li class="underline"><p><a href="gallery.php">GALERIJA</a></p></li>
		</ul>
	</div>
	<div id="menuFooter">
		<p>Prijavite se za newsletter</p>
		<form>
			<input type="text" placeholder="e-Mail" name="">
			<input id="submitNewsletter" type="submit" value="Prijavite se" name="">
		</form>
	</div>
</div>

<div id="loadingBar">
	<img id="loadingGif" src="icon/loading.gif">
	<img id="loadingLogo" src="icon/logo.png">
</div>